export const environment = {
  production: true,
  firebase: {
    apiKey: "AIzaSyCD59LCimh7OSfocyOw8V24vbD5H-1cUDY",
    authDomain: "meals-316701.firebaseapp.com",
    projectId: "meals-316701",
    storageBucket: "meals-316701.appspot.com",
    messagingSenderId: "612120718513",
    appId: "1:612120718513:web:e1ef83177f3e369613c690",
    measurementId: "G-KKL391LNKB"
  }
};
